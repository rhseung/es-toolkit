'use strict';

function last(arr) {
  return arr[arr.length - 1];
}
exports.last = last;
