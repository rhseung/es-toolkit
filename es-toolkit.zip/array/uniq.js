'use strict';

function uniq(arr) {
  return Array.from(new Set(arr));
}
exports.uniq = uniq;
