'use strict';

function take(arr, count) {
  return arr.slice(0, count);
}
exports.take = take;
