'use strict';

function initial(arr) {
  return arr.slice(0, -1);
}
exports.initial = initial;
