'use strict';

function head(arr) {
  return arr[0];
}
exports.head = head;
