'use strict';

function tail(arr) {
  return arr.slice(1);
}
exports.tail = tail;
