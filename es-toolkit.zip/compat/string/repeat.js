'use strict';

function repeat(str, n) {
  return str.repeat(n);
}
exports.repeat = repeat;
