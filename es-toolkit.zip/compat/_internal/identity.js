'use strict';

function identity(x) {
  return x;
}
exports.identity = identity;
