'use strict';

var isRegExp$1 = require('../../predicate/isRegExp.js');
function isRegExp(value) {
  return isRegExp$1.isRegExp(value);
}
exports.isRegExp = isRegExp;
