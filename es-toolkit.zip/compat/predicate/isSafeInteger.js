'use strict';

function isSafeInteger(value) {
  return Number.isSafeInteger(value);
}
exports.isSafeInteger = isSafeInteger;
