'use strict';

function isNaN(value) {
  return Number.isNaN(value);
}
exports.isNaN = isNaN;
