'use strict';

function isString(value) {
  return typeof value === 'string' || value instanceof String;
}
exports.isString = isString;
