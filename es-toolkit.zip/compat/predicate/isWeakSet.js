'use strict';

var isWeakSet$1 = require('../../predicate/isWeakSet.js');
function isWeakSet(value) {
  return isWeakSet$1.isWeakSet(value);
}
exports.isWeakSet = isWeakSet;
