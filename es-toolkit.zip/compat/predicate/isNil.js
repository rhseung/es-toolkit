'use strict';

function isNil(x) {
  return x == null;
}
exports.isNil = isNil;
