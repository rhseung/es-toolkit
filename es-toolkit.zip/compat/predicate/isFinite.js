'use strict';

function isFinite(value) {
  return Number.isFinite(value);
}
exports.isFinite = isFinite;
