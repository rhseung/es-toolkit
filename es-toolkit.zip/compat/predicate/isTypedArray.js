'use strict';

var isTypedArray$1 = require('../../predicate/isTypedArray.js');
function isTypedArray(x) {
  return isTypedArray$1.isTypedArray(x);
}
exports.isTypedArray = isTypedArray;
