'use strict';

function isInteger(value) {
  return Number.isInteger(value);
}
exports.isInteger = isInteger;
