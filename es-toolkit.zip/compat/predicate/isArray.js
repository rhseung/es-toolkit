'use strict';

function isArray(value) {
  return Array.isArray(value);
}
exports.isArray = isArray;
