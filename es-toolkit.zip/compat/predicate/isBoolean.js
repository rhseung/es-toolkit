'use strict';

function isBoolean(value) {
  return typeof value === 'boolean' || value instanceof Boolean;
}
exports.isBoolean = isBoolean;
