'use strict';

function noop() {}
exports.noop = noop;
