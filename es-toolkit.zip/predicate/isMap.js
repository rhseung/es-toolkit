'use strict';

function isMap(value) {
  return value instanceof Map;
}
exports.isMap = isMap;
