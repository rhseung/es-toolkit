'use strict';

function isString(value) {
  return typeof value === 'string';
}
exports.isString = isString;
