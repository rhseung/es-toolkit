'use strict';

function isNotNil(x) {
  return x != null;
}
exports.isNotNil = isNotNil;
