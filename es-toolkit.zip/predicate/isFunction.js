'use strict';

function isFunction(value) {
  return typeof value === 'function';
}
exports.isFunction = isFunction;
