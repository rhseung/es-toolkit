'use strict';

function isNull(x) {
  return x === null;
}
exports.isNull = isNull;
