'use strict';

function isUndefined(x) {
  return x === undefined;
}
exports.isUndefined = isUndefined;
