'use strict';

function isArrayBuffer(value) {
  return value instanceof ArrayBuffer;
}
exports.isArrayBuffer = isArrayBuffer;
