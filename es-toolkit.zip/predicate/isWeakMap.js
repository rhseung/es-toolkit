'use strict';

function isWeakMap(value) {
  return value instanceof WeakMap;
}
exports.isWeakMap = isWeakMap;
