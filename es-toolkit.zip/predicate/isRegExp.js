'use strict';

function isRegExp(value) {
  return value instanceof RegExp;
}
exports.isRegExp = isRegExp;
