'use strict';

function isDate(value) {
  return value instanceof Date;
}
exports.isDate = isDate;
