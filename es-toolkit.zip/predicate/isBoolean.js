'use strict';

function isBoolean(x) {
  return typeof x === 'boolean';
}
exports.isBoolean = isBoolean;
