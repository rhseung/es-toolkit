'use strict';

function isError(value) {
  return value instanceof Error;
}
exports.isError = isError;
