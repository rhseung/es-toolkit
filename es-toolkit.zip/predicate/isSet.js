'use strict';

function isSet(value) {
  return value instanceof Set;
}
exports.isSet = isSet;
