'use strict';

function upperFirst(str) {
  return str.substring(0, 1).toUpperCase() + str.substring(1);
}
exports.upperFirst = upperFirst;
