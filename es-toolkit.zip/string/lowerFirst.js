'use strict';

function lowerFirst(str) {
  return str.substring(0, 1).toLowerCase() + str.substring(1);
}
exports.lowerFirst = lowerFirst;
